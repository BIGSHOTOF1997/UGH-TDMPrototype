//
//  AccountMenu.swift
//  UberCharge
//
//  Created by Tyler Kiong on 19/9/23.
//

import SwiftUI

struct AccountMenu: View {
    
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var birthdate = Date()
    @State private var paymeth = ""
    
    var body: some View {
        NavigationView {
            Form {
                
                Section(header: Text("Particulars")) {
                    TextField("First Name", text: $firstName)
                    TextField("Last Name", text: $lastName)
                    DatePicker("Date of Birth", selection: $birthdate, displayedComponents: .date)
                }
                Section(header: Text("Payment")) {
                    TextField("Payment Method", text: $paymeth)
                }
            }
            .navigationTitle("Your Account")
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button("Save", action: saveUser)
                }
            }
        }
        .accentColor(.red)
    }
    
    func saveUser() {
        print("User Saved")
    }
}


struct AccountMenu_Previews: PreviewProvider {
    static var previews: some View {
        AccountMenu()
    }
}
