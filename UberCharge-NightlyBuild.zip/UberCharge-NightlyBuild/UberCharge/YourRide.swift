//
//  YourRide.swift
//  UberCharge
//
//  Created by Tyler Kiong on 20/9/23.
//

import SwiftUI

struct YourRide: View {
    var body: some View {
        VStack {
            Rectangle()
                .fill(Color.indigo)
                .frame(width: 450, height: 360)
                .position(x:200, y:700)
                .padding(.all, 10)
                .background(Color.cyan)
            Text("THIS SCREEN IS UNDER MAINTENANCE!")
                .position(x:196.5, y:30)
                .bold()
                .shadow(radius: 5)
        }
    }
}

struct YourRide_Previews: PreviewProvider {
    static var previews: some View {
        YourRide()
    }
}
