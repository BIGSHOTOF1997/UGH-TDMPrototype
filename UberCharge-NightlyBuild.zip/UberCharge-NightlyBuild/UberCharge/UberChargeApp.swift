//
//  UberChargeApp.swift
//  UberCharge
//
//  Created by Tyler Kiong on 19/9/23.
//

import SwiftUI

@main
struct UberChargeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
